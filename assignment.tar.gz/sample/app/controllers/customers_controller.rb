class CustomersController < ApplicationController
	def new
		@customer = Customer.new
		
	end

	def show
end

	def create
		@customer= Customer.new(message_params)
		if @customer.save
			redirect_to new_customer_path
			
		end

		
	end
	def message_params
      params.require(:customer).permit(:name, :email, :password, :repassword)
    end
end
