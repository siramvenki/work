class SearchController < ApplicationController
  def new
  end
end
