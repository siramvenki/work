class LoginController < ApplicationController
  def new
  end
end
