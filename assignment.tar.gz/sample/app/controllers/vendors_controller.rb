class VendorsController < ApplicationController
	def new
		@vendor = Vendor.new
		
	end
	

	def create
		@vendor= Vendor.new(message_params)
		if @vendor.save
			redirect_to new_vendor_path, :notice => "Signed up!"
			
		end

		
	end
	def message_params
      params.require(:vendor).permit(:name, :email, :password, :repassword, :bussiness , :place)
    end
end
