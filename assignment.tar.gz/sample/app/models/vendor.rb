class Vendor < ApplicationRecord
end
