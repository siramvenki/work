Rails.application.routes.draw do
  get 'search/new'

  get 'login/new'

  get 'clogin/login'

  get 'clogin/search'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  resources :students
  resources :customers
  resources :vendors
  resources :clogin
  resources :search

end
