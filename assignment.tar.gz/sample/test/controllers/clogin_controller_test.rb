require 'test_helper'

class CloginControllerTest < ActionDispatch::IntegrationTest
  test "should get login" do
    get clogin_login_url
    assert_response :success
  end

  test "should get search" do
    get clogin_search_url
    assert_response :success
  end

end
