class CreateCustomers < ActiveRecord::Migration[5.1]
  def change
    create_table :customers do |t|
    	has_secure_password
      t.string :name
      t.string :email
      t.string :password
      t.string :repassword

      t.timestamps
    end
  end
end
